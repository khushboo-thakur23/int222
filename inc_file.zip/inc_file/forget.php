<html><head>
<title>FORGET PASSWORD</title>
</head>
<body>
<?php
$a=getdate();
$b=$a['mday'];
$c=$a['mon'];
$d=$a['year'];

echo "<table bgcolor='#557598' width='100%' border='0' align='center'>"
."<tr align='right'>"
."<td width='84%'>"
."<img src='twtr.png'>"
."</td>"
."<td align='center'>"
."<font color='sky blue'>"
."ASK   1800 180 1961/1961"
."</FONT>"
."</TD>"
."</TR>"
."</TABLE>"
."<table bgcolor='#DFEBF9' width='100%' border='0' align='center'>"
."<tr align='left'>"
."<td align='center'>"
."<font color='#056BD6'>"
."DATE:- ".$b."-".$c."-".$d
."</TD>"
."<td width='60%'>"
."<font color='SKY BLUE'>"
."INCOME TAX DEPARTMENT"
."</FONT>"
." > "
."<font color='SKY BLUE'>"
."USER LOGIN"
."</FONT>"
." > "
."<font color='GRAY'>"
."FORGET PASSWORD"
."</FONT>"
."</td>"
."<td ALIGN='RIGHT'>"
."FOLLOW US ON"
."<a href='http://www.facebook.com'><img src='fb.png' height='21' width='23'></a>"
."<a href='http://www.twitter.com'><img src='twt.png' height='21' width='23'></a>"
."<a href='http://www.youtube.com'><img src='U_tub.png' height='21' width='23'></a>"
."  "
."<a href='home.php'>"
."<img src='back.jpg' height='25' width='25'>"
."GO HOME"
."</a>"
."</td>"
."</TR>"
."</TABLE>";
?>
<hr size="5" color="orange">
<img src="logo2.jpg" align="left" height="23%" width="13%">
<img src="logo.PNG" align="right" height="22%" width="12%">
<br>
<center>
<font color="crymson" face="Segoe Print" size="7"><b><u>INCOME TAX DEPARTMENT</u></b></font></center>
<hr size="2" color="navy">
<br><marquee behavior="alternate" scrollamount="7" width="100%">
<font color="blue">*Press note regarding: Filing of Revised Income Tax Returns by the Tax Payers Post De-Monetisation of Currency</font></marquee>
<br>
<hr size="6" color="red">
<form method="post"action="http://localhost:/inc_file/forget.php" name="frm">
<TABLE WIDTH="70%" align="center" BGCOLOR="PEACHPUFF" BORDER="3" BORDERCOLOR="#4D04A3">
<TR align="center">
<td>
 <font size="4" color="crimson">
 ENTER YOUR PAN NO.:-
 </font>
</td>
<td>
<input type="text" name="t1" maxlength="14" onChange="ch()">
</td>
</tr>
<tr align="center">
<td>
<font size="4" color="crimson">
ENTER YOUR NEW PASSWORD:-
</font>
</td>
<td>
<input type="password" name="t2"  maxlength="14">
</td>
</tr>
<tr align="center">
<td>
<font size="4" color="crimson">
CONFIRM YOUR NEW PASSWORD:-
</font>
<td>
<input type="password" name="t3" maxlength="14">
</td>
</tr>
<tr align="center">
<td colspan="2">
<input type="submit" value="LOGIN" name="b1">
</td>
</tr>
</table>
 <hr color=blue size=4>
 <script>
 function ch()
 {
	 var a,b;
	 a=frm.t1.value;
	 b=a.length;
	 if (b!==14)
	 {
		 alert('Please Check Your PAN NO.');
	 }
 }
 </script>
 <?php
$srvname="localhost";
$usrname="root";
$pass="";
$db="income_tax";
//create connection
if (isset($_POST['b1']))
{
$pan=$_POST['t1'];
$z=strlen($pan);
$ne=$_POST['t2'];
$conf=$_POST['t3'];
	if (($ne==$conf) && ($z==14))
	{
		$pas=$ne;
		$con=new mysqli($srvname,$usrname,$pass,$db);
			if($con->connect_error)
				{
						echo "Connection Failed";
				}
			else
				{
						echo "Connected To Database";
							echo $pas;
							echo $conf;
							echo $pan;
		$updt="UPDATE registration SET PASSWORD = '$pas' WHERE PAN_NO = '$pan'";
			if($con->query($updt))
				{
					header('location: login.php');
				}
				}
	}
	else
	{
		echo "<FONT COLOR='RED' SIZE='3'>"."<B>"."NEW AND CONFERM PASSWORD DOES NOT MATCH... OR INCORRECT PAN NO. Try Again!!!"."</B>"."</FONT>";
	}
	
}
?>
</body>
</html>