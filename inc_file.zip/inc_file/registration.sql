-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Dec 29, 2016 at 06:28 PM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 5.6.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `income_tax`
--

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE `registration` (
  `PAN_NO` bigint(20) NOT NULL,
  `USER_NAME` text NOT NULL,
  `PASSWORD` text NOT NULL,
  `NAME` text NOT NULL,
  `DOB` text NOT NULL,
  `MOBILE_NO` bigint(20) NOT NULL,
  `ADDRESS` text NOT NULL,
  `PIN_NO` int(11) NOT NULL,
  `STATE` text NOT NULL,
  `EMAIL` text NOT NULL,
  `BANK` text NOT NULL,
  `ACCOUNT_NO` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `registration`
--

INSERT INTO `registration` (`PAN_NO`, `USER_NAME`, `PASSWORD`, `NAME`, `DOB`, `MOBILE_NO`, `ADDRESS`, `PIN_NO`, `STATE`, `EMAIL`, `BANK`, `ACCOUNT_NO`) VALUES
(12344566, 'aman56', '12345678', 'AMAN KHAN', '6-may-1971', 9943434545, 'dfgdfgd2d2545dfd', 566626, 'Madhya Pradesh', 'dfgdfgdg', 'AXIS BANK', 5645654526851),
(2147483647, 'gbc', '', 'ghfhf', '2-april-1952', 98765544332, 'chnbxcvnxzbn', 787875, 'Jammu & Kashmir', 'hjhgngfngfn', 'IDBI BANK', 9223372036854775807),
(12143264325633, 'nadeem', '12', 'nadeem', '1-january-1990', 9823789246, 'dghwc', 764745, 'Andhra Pradesh', 'wdchbghcj', 'PUNJAB NATIONAL BANK', 4375647847847847),
(12345678910111, 'aman', 'aman', 'aman patel', '15-june-1975', 9616988692, 'ddddfd', 564535, 'Uttar Pradesh', 'jdhkchdvf', 'INDIAN BANK', 5465354353653245),
(12345678910122, 'nadeem', '12', 'MD. NADEEM', '15-june-1990', 9898989898, 'mallawan', 241302, 'Andhra Pradesh', 'mdnadeem897mallawan@gmail.com', 'STATE BANK OF INDIA', 3440000780078655),
(99887766554433, 'aman@bld', 'aman', 'AMAN PATEL', '9-april-1967', 9719192997, 'near hanumaan mandir bisalpur road bilsanda, pilibhit', 262202, 'Uttar Pradesh', 'imamanpatel99@gmail.com', 'BANK OF INDIA', 1700035006736734);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `registration`
--
ALTER TABLE `registration`
  ADD PRIMARY KEY (`PAN_NO`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
