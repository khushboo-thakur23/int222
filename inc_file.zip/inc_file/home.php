<html><head>
<title>INCOME TAX</title>
</head>
<body>
<?php
$handle = fopen("counter.txt", "r");
if(!$handle){
 echo "could not open the file" ;
}
	$counter = ( int ) fread ($handle,20) ;
	fclose ($handle) ;
	$counter++ ;
$handle =  fopen("counter.txt", "w" ) ;
fwrite($handle,$counter) ;
fclose ($handle) ;
$a=getdate();
$b=$a['mday'];
$c=$a['mon'];
$d=$a['year'];

echo "<table bgcolor='#557598' width='100%' border='0' align='center'>"
."<tr align='right'>"
."<td width='84%'>"
."<img src='twtr.png'>"
."</td>"
."<td align='center'>"
."<font color='sky blue'>"
."ASK   1800 180 1961/1961"
."</FONT>"
."</TD>"
."</TR>"
."</TABLE>"
."<table bgcolor='#DFEBF9' width='100%' border='0' align='center'>"
."<tr align='left'>"
."<td align='center'>"
."<font color='#056BD6'>"
."DATE:- ".$b."-".$c."-".$d
."</TD>"
."<td width='30%'>"
."<font color='GRAY'>"
."INCOME TAX DEPARTMENT"
."</FONT>"
."</td>"
."<td align='left' width='30%'>"
."<font color='red'>"
."VISITORS COUNT - ".$counter
."</font>"
."</td>"
."<td ALIGN='RIGHT'>"
."FOLLOW US ON"
."<a href='http://www.facebook.com'><img src='fb.png' height='6%' width='10%'></a>"
."<a href='http://www.twitter.com'><img src='twt.png' height='6%' width='10%'></a>"
."<a href='http://www.youtube.com'><img src='U_tub.png' height='6%' width='10%'></a>"
."</TD>"
."</TR>"
."</TABLE>";
?>
<hr size="5" color="orange">
<img src="logo2.jpg" align="left" height="23%" width="13%">
<img src="logo3.jpg" align="right" height="23%" width="13%"><br>
<center><font color="crymson" face="Segoe Print" size="7"><b><u>INCOME TAX DEPARTMENT</u></b></font></center>
<hr size="2" color="navy">
<br><marquee behavior="alternate" scrollamount="7" width="100%">
<font color="blue">*Press note regarding: Filing of Revised Income Tax Returns by the Tax Payers Post De-Monetisation of Currency</font></marquee>
<br>
<hr size="2" color="navy">
<table bgcolor="cyan" border="0" align="center" width="100%">
<tr>
<td align="center" onMouseOver="document.bgColor='yellow'">
<a href="tax_calc.php"><font color="teal"><b>TAX CALCULATOR</b></font></a>
</TD>
<TD align="center" onMouseOver="document.bgColor='sky blue'">
<a href="login.php"><font color="teal"><b>USER LOGIN</b></font></a>
</TD>
<TD align="center" onMouseOver="document.bgColor='peachpuff'">
<a href="regis.php"><font color="teal"><b>NEW REGISTRATION</b></font></a>
</TD>
<td align="center" onMouseOver="document.bgColor='grey'">
<a href="about.php"><font color="teal"><b>ABOUT US</b></font></a>
</TD>
</Tr>
</table>

<table width="100%" border="0" height="40%">
<tr>
<td width="50%">
<table width="100%" height="6%" bgcolor="#FC4638">
<tr align="center"><td><FONT COLOR="#4D04A3" SIZE="5">
<B>Testimonials & Achievements </B></FONT></TD></TR>
</TABLE>
<marquee direction="up" scrollamount="2" width="100%" height="250" >
<font color="#4C03A3">* Online provision for viewing of tax credits and specified transactions to the taxpayer<br>
* National Website is taxpayer friendly which is evident from following statistics<br>
&nbsp&nbsp• From 01st October, 2014 – 31st August, 2015<br>
&nbsp&nbsp&nbsp&nbsp> Total Hits – 116.38 Crore (approx.)<br>
&nbsp&nbsp&nbsp&nbsp> Total Visitors – 3.37 Crore (approx.)<br>
&nbsp&nbsp&nbsp&nbsp> Total Page Views – 36.79 Crore (approx.)<br>
* "E filing is possible within minutes. "<br>
* "Good initiative ITR-V everification "<br>
* "Speedy disposal of limited scrutiny cases - Both the CA and tax payers fraternity are feeling that   the Acche Din has come for us."<br>
* " Income tax return processed in record time. Excellent. "<br>
* "Great work and really efficient software which is easy for any layman to file returns"<br>
<B>* More than 13,500 PAN application receipt Centers all over India<br>
* More than 20 Lakh PAN applications processed per month<br>
* Corporates get PAN and TAN allotment immediately after issue of Corporate Identity Number (CIN) by MCA<br>
* Facility of payment of taxes through Net Banking/ATMs & at more than 17,000 branches of 31 designated banks<br>
* Seamless e-Filing facility for uploading of Income Tax Returns anywhere and anytime around the clock<br>
• About 2,00,00,000 returns filed till 31st Aug’ 15 in current financial year <br>
* Awards<br></b>
• National E-Governance Silver Award (2007-08)<br>
• National “Gold” E-Governance Award 2010-11<br>
• National E-Governance Gold Award (2014-15)<br>
• Prime Minister’s Award for excellence in Public Administration </FONT>

</marquee>
</td>
<td>
<div class="slideshow-container" align="right" height="250">
<div class="mySlides fade" >
<img src="img2.jpg" style="width:655;height:285">
</div>
<div class="mySlides fade">
<img src="img3.jpg" style="width:655;height:285">
</div>
<div class="mySlides fade">
<img src="img8.jpg" style="width:655;height:285">
</div>
<div class="mySlides fade">
<img src="img4.jpg" style="width:655;height:285">
</div>
</div>

<div style="text-align:center">
<span class="dot"></span>
<span class="dot"></span>
<span class="dot"></span>
<span class="dot"></span>
</div>
<script>
var slideIndex=3;
showSlides();
function showSlides()
{
var i;
var slides=document.getElementsByClassName("mySlides");
var dots=document.getElementsByClassName("dot");
for (i=0; i<slides.length; i++)
{
slides[i].style.display="none";
}
slideIndex++;
if (slideIndex>slides.length)
{
slideIndex=1;
}
for (i=0; i<dots.length; i++)
{
dots[i].className=dots[i].className.replace("active","");
}
slides[slideIndex-1].style.display="block";
dots[slideIndex-1].className+="active";
setTimeout(showSlides,4000);
}
</script>
</td>
</tr></table>
<HR size="8" COLOR="crimson">
<table bgcolor="#00AF8A" WIDTH="33%" align="right">
<TR ALIGN="center">
<td>
<font color="#FA2E21" size="5">
<b>150 Years Celebration Short Film</b>
</font>
</td>
</tr>
<tr>
<td>
<video src="vd.mp4" controls="controls" autoplay="autoplay" LOOP="" WIDTH="100%" HEIGHT="80%"></video>
</td>
</tr>
</table><div class="slideshow-container" align="left" height="50%">
<div class="mySlide fade" >
<img src="news8.jpg" style="width:67%;height:380">
</div>
<div class="mySlide fade">
<img src="news2.jpg" style="width:67%;height:380">
</div>
<div class="mySlide fade">
<img src="news9.jpg" style="width:67%;height:380">
<a href="news.php"><B><i>Click Here To View More News</i></b></a>
</div>
<div class="mySlide fade">
<img src="news.jpg" style="width:67%;height:380">
</div>
</div>

<div style="text-align:center">
<span class="do"></span>
<span class="do"></span>
<span class="do"></span>
<span class="do"></span>
</div>
<script>
var slideInde=3;
showSlide();
function showSlide()
{
var i;
var slide=document.getElementsByClassName("mySlide");
var d=document.getElementsByClassName("do");
for (i=0; i<slide.length; i++)
{
slide[i].style.display="none";
}
slideInde++;
if (slideInde>slide.length)
{
slideInde=1;
}
for (i=0; i<d.length; i++)
{
d[i].className=d[i].className.replace("active","");
}
slide[slideInde-1].style.display="block";
d[slideInde-1].className+="active";
setTimeout(showSlide,6300);
}
</script>
<hr>
<table bgcolor="gray" width="100%" height="10%">
<tr align="center">
<td>
Disclaimer
</td>
</tr>
<tr><td><marquee>  *Recruitment, training and all other matters relating to service conditions and career prospects of all personnel of the Income-tax Department.Policy regarding grant of rewards and appreciation certificates.Any other matter, which the Chairman or any Member of the Board, with the approval of the Chairman, may refer for joint consideration of the Board.  </marquee></td></tr>
</table>
</body></html>