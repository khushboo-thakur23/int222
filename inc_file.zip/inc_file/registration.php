<?php
$db="income_tax";
function run()
{
$pan=$_POST['pan'];
$c=strlen($pan);
$user=$_POST['usr'];
$password=$_POST['pass'];
$a=$_POST['name'];
$name=strtoupper($a);
$dob=$_POST['date']."-".$_POST['month']."-".$_POST['year'];
$mobile=$_POST['mobile'];
$b=$_POST['address'];
$address=strtoupper($b);
$pin=$_POST['pin'];
$state=$_POST['state'];
$email=$_POST['email'];
$bank=$_POST['bank'];
$account=$_POST['account'];
$z=strlen($account);
if (($c==14) && ($z==16))
{
echo "<body bgcolor='peachpuff'><table align='center' width='95%' border='3' bgcolor='#E7A7B6' height='100%' BORDERCOLOR='#FC4638'>
<TR height='20%'>
<TD COLSPAN='5' align='center' BGCOLOR='#4D04A3'><font color='#FC4638' face='Chiller' size='7'><b>YOUR INFORMATION HAS BEEN REGISTERED.</b></font></TD></TR>
<tr>
<td colspan='6' width='50%' align='center'>
<font size='3'>
YOUR PAN<FONT COLOR='CRYMSON'>(*Personal Account Number)</font> NO:-
</FONT>".$pan."</td>
<tr  height='10%'  align='center'>
<td width='10%'>
<font size='3'>
YOUR NAME:-
</FONT>"
.$name."</td>
<td width='8%'>
<font size='3'>
USER NAME:-
</FONT>".$user."
</td>
<td colspan='2' width='17%'>
<font size='3'>YOUR E-MAIL ACCOUNT :-".$email.
"</td>
<td colspan='2'>
&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbspYOUR DATE OF BIRTH:-".$dob."</td>
</tr>
<tr align='center' height='15%'>
<td colspan='2'>
<font size='3'>
ASSESSMENT YEAR:-
</FONT>
2017-18
</td>
<td colspan='2'>
<font size='3'>
YOUR MOBILE NO.:-
</FONT>".$mobile."</td>
<td COLSPAN='2'>
<font size='3'>
ADDRESS:-
</FONT>".$address."</TD>
</tr>
<tr align='center' height='10%'>
<td>
<font size='3'>
PIN CODE:-
</FONT>".$pin."</td>
<td>
<font size='3'>
STATE:-
</FONT>".$state."
</td>
<td colspan='2'>
<font size='3'>
BANK NAME:-".$bank."
</td>
<td colspan='2'>
<font size='3'>
BANK ACC. NO. :-".$account."
</td>
</tr>
<tr>
<td colspan='6' align='center' height='20%'>
<A HREF='LOGIN.PHP'><input type='submit' value='Click Here To LOGIN'></a>
</td>
</tr>
</table>
</body>";

$sub=mysql_query("insert into registration values($pan,'$user','$password','$name','$dob',$mobile,'$address','$pin','$state','$email','$bank','$account')");

}
else
{
	die('YOU CAN NOT REGISTERED RIGHT NOW...CHECK YOUR PAN NO. OR BANK ACCOUNT NO. AND TRY AGAIN');
}
}			
			
if(isset($_POST["submit"]))
{
	$con=Mysql_connect("localhost","root","");
	mysql_select_db($db,$con);
	if($con)
	{
		run();
	}
	else 
	{
		echo "connection failed";
		
	}
}
?>