<html><head>
<title>NEWS CLIPS</title>
</head>
<body bgcolor="yellow">
<?php
$a=getdate();
$b=$a['mday'];
$c=$a['mon'];
$d=$a['year'];

echo "<table bgcolor='#557598' width='100%' border='0' align='center'>"
."<tr align='right'>"
."<td width='84%'>"
."<img src='twtr.png'>"
."</td>"
."<td align='center'>"
."<font color='sky blue'>"
."ASK   1800 180 1961/1961"
."</FONT>"
."</TD>"
."</TR>"
."</TABLE>"
."<table bgcolor='#DFEBF9' width='100%' border='0' align='center'>"
."<tr align='left'>"
."<td align='center'>"
."<font color='#056BD6'>"
."DATE:- ".$b."-".$c."-".$d
."</TD>"
."<td width='50%'>"
."<font color='SKY BLUE'>"
."INCOME TAX DEPARTMENT"
."</FONT>"
." > "
."<font color='GRAY'>"
."NEWS CLIPS"
."</FONT>"
."</td>"
."<td ALIGN='RIGHT'>"
."FOLLOW US ON"
."<a href='http://www.facebook.com'><img src='fb.png' height='21' width='23'></a>"
."<a href='http://www.twitter.com'><img src='twt.png' height='21' width='23'></a>"
."<a href='http://www.youtube.com'><img src='U_tub.png' height='21' width='23'></a>"
."  "
."<a href='home.php'>"
."<img src='back.jpg' height='25' width='25'>"
."GO HOME"
."</a>"
."</TD>"
."</TR>"
."</TABLE>"
."<hr size='4' color='crymson'>";
?>
<marquee bgcolor="green" scrollamount="9" behavior="alternate">
<font color="#FC4638" size="6">
SOME CENTRAL & LOCAL NEWS</font>
</marquee>
<center><script>
for (a=1 ;a<=13 ;a++)
{
	document.write("<img src='newsimg/news ("+a+").jpg' height='48%' width='32.9%' border='5.3'> &nbsp");
}
</script>
<center>
</body>
</html>
