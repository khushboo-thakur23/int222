<html>
<body background="restr.png">
<?php
$a=getdate();
$b=$a['mday'];
$c=$a['mon'];
$d=$a['year'];

echo "<table bgcolor='#557598' width='100%' border='0' align='center'>"
."<tr align='right'>"
."<td width='84%'>"
."<img src='twtr.png'>"
."</td>"
."<td align='center'>"
."<font color='sky blue'>"
."ASK   1800 180 1961/1961"
."</FONT>"
."</TD>"
."</TR>"
."</TABLE>"
."<hr height='2%'>"
."<table bgcolor='#DFEBF9' width='100%' border='0' align='center'>"
."<tr align='left'>"
."<td align='center'>"
."<font color='#056BD6'>"
."DATE:- ".$b."-".$c."-".$d
."</TD>"
."<td width='60%'>"
."<font color='sky blue'>"
."INCOME TAX DEPARTMENT"
."</FONT>"
." > "
."<font color='sky blue'>"
."USER LOGIN"
."</FONT>"
." > "
."<font color='gray'>"
."PAY ITR"
."</FONT>"
."</td>"
."<td ALIGN='RIGHT'>"
."FOLLOW US ON"
."<img src='fb.png' height='6%' width='10%'>"
."<img src='twt.png' height='6%' width='10%'>"
."<img src='U_tub.png' height='6%' width='10%'>"
."</TD>"
."</TR>"
."</TABLE>";
?>
<form  name="frm" method="post" action="http://localhost/inc_file/userpay.php"><br><br><br>
<table width="50%" border="0" bgcolor="#FA7277" HEIGHT="10%" align="center">
<tr>
<td bgcolor="#FA7277" align="center"><font color="MAROON" size="6"><b><u>FILE YOUR ITR</U></b></font></td>
</tr>
</table>
<table bgcolor="#E7A7B6" width="50%" border="0" HEIGHT="60%" align="center">
<tr ALIGN="center" >
<td>
ASSESSMENT YEAR:- 
</TD>
<TD>
2017-18
</td>
</tr>

<tr ALIGN="center">
<td>
TAX PAYER:- 
</TD>
<TD>
<select size="0">
<option>INDIVIDUAL</option>
</select>
</td>
</tr>
<tr ALIGN="center">
<td>
ENTER YOUR PAN NO.:- 
</TD>
<TD>
<input type="text" name="pan" maxlength="14"size="30" onChange="ch()">
</td>
</tr>
<tr align="center">
<td>
ENTER YOUR INCOME:- 
</TD>
<TD>
<input type="text" name="income" size="30">
</td>
</tr>
<tr align="center" ><td colspan="2">
<input type="submit" name="submit" value="PAY ITR">
<input type="reset" value="Reset">
</td>
</tr></table>
<script>
function ch()
{
	var a=frm.pan.value;
	var b=a.length;
	if (b<14)
	{
		alert('Please check your PAN NO.');
	}
}
</script>
	</body></html>