<html>
<head>
<title>
USER REGISTRATION
</title>
</HEAD>
<body bgcolor="peachpuff">
<?php
$a=getdate();
$b=$a['mday'];
$c=$a['mon'];
$d=$a['year'];

echo "<table bgcolor='#557598' width='100%' border='0' align='center'>"
."<tr align='right'>"
."<td width='84%'>"
."<img src='twtr.png'>"
."</td>"
."<td align='center'>"
."<font color='sky blue'>"
."ASK   1800 180 1961/1961"
."</FONT>"
."</TD>"
."</TR>"
."</TABLE>"
."<hr height='2%'>"
."<table bgcolor='#DFEBF9' width='100%' border='0' align='center'>"
."<tr align='left'>"
."<td align='center'>"
."<font color='#056BD6'>"
."DATE:- ".$b."-".$c."-".$d
."</TD>"
."<td width='50%'>"
."<font color='SKY BLUE'>"
."INCOME TAX DEPARTMENT"
."</FONT>"
." > "
."<font color='GRAY'>"
."NEW REGISTRATION"
."</FONT>"
."</td>"
."<td ALIGN='RIGHT'>"
."FOLLOW US ON"
."<a href='http://www.facebook.com'><img src='fb.png' height='21' width='23'></a>"
."<a href='http://www.twitter.com'><img src='twt.png' height='21' width='23'></a>"
."<a href='http://www.youtube.com'><img src='U_tub.png' height='21' width='23'></a>"
."  "
."<a href='home.php'>"
."<img src='back.jpg' height='25' width='25'>"
."GO HOME"
."</a>"
."</TD>"
."</TR>"
."</TABLE>";
?>
<form method="post" action="http://localhost/inc_file/registration.php" name="frm">
<table align="center" width="95%" border="3" bgcolor="#E7A7B6" height="100%" BORDERCOLOR="#FC4638">
<TR>
<TD COLSPAN="4" align="center" BGCOLOR="#4D04A3"><font color="#FC4638" face="Chiller" size="7"><b>NEW USER REGISTRATION FORM</b></font></TD></TR>
<tr>
<td colspan="2" width="50%" align="right">
<font size="3">
ENTRE PAN<FONT COLOR="CRYMSON">(*Personal Account Number)</font> NO:-
</FONT>
</td>
<td colspan="2" width="50%" align="left">
<input type="text" name="pan" size="50" maxlength="14" onChange="ch()">
</td>
</tr>
<tr align="center">
<td>
<font size="3">
ENTER NAME:-
</FONT>
</td>
<td>
<input type="text"name="name" size="50">
</td>
<td>
<font size="3">
USER NAME:-
</FONT>
</td>
<td>
<input type="text" name="usr" size="50">
</td>
</tr>
<tr>
<td colspan="2" align="CENTER">
<font size="3">
PASSWORD:-&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
<input type="password"name="pass" size="50">
</FONT>
</td>
<td colspan="2" ALIGN="LEFT">
&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbspSELECT YOUR DATE OF BIRTH:-
<select name="date">
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
<option value="6">6</option>
<option value="7">7</option>
<option value="8">8</option>
<option value="9">9</option>
<option value="10">10</option>
<option value="11">11</option>
<option value="12">12</option>
<option value="13">13</option>
<option value="14">14</option>
<option value="15">15</option>
<option value="16">16</option>
<option value="17">17</option>
<option value="18">18</option>
<option value="19">19</option>
<option value="20">20</option>
<option value="21">21</option>
<option value="22">22</option>
<option value="23">23</option>
<option value="24">24</option>
<option value="25">25</option>
<option value="26">26</option>
<option value="27">27</option>
<option value="28">28</option>
<option value="29">29</option>
<option value="30">30</option>
<option value="31">31</option>
</select>
<SELECT NAME="month">
<option value="january">January</option>
<option value="february">February</option>
<option value="march">March</option>
<option value="april">April</option>
<option value="may">May</option>
<option value="june">June</option>
<option value="july">July</option>
<option value="august">August</option>
<option value="september">Septemner</option>
<option value="october">October</option>
<option value="november">November</option>
<option value="december">December</option>
</select>

<SELECT NAME="year">
<option value="1990">1990</option>
<option value="1989">1989</option>
<option value="1988">1988</option>
<option value="1987">1987</option>
<option value="1986">1986</option>
<option value="1985">1985</option>
<option value="1984">1984</option>
<option value="1983">1983</option>
<option value="1982">1981</option>
<option value="1980">1980</option>
<option value="1979">1979</option>
<option value="1978">1978</option>
<option value="1977">1977</option>
<option value="1976">1976</option>
<option value="1975">1975</option>
<option value="1974">1974</option>
<option value="1973">1973</option>
<option value="1972">1972</option>
<option value="1971">1971</option>
<option value="1970">1970</option>
<option value="1969">1969</option>
<option value="1968">1968</option>
<option value="1967">1967</option>
<option value="1966">1966</option>
<option value="1965">1965</option>
<option value="1964">1964</option>
<option value="1963">1963</option>
<option value="1962">1962</option>
<option value="1961">1961</option>
<option value="1960">1960</option>
<option value="1959">1959</option>
<option value="1958">1958</option>
<option value="1957">1957</option>
<option value="1956">1956</option>
<option value="1955">1955</option>
<option value="1954">1954</option>
<option value="1953">1953</option>
<option value="1952">1952</option>
<option value="1951">1951</option>
<option value="1950">1950</option>
</select>
</td>
</tr>
<tr align="center">
<td colspan="2">
<font size="3">
ASSESSMENT YEAR:-
</FONT>
2017-18
</td>
<td>
<font size="3">
ENTER MOBILE NO.:-
</FONT>
</td>
<td>
<input type="text"name="mobile" size="50" maxlength="10">
</td>
</tr>
<tr align="center">
<td COLSPAN="2">
<font size="3">
ADDERESS:-
</FONT>
<input type="text"name="address" size="50">
<td COLSPAN="2">
<font size="3">
PIN CODE:-
</FONT>
<input type="text"name="pin" size="6" maxlength="6">
<font size="3">
STATE:-
</FONT>
<select name="state">
<option value="Andhra Pradesh">Andhra Pradesh</option>
<option value="Arunachal Pradesh">Arunachal Pradesh</option>
<option value="Assam">Assam</option>
<option value="Bihar">Bihar</option>
<option value="Chattisgarh">Chattisgarh</option>
<option value="Goa">Goa</option>
<option value="Gujarat">Gujarat</option>
<option value="Haryana">Haryana</option>
<option value="Himachal Pradesh">Himachal Pradesh</option>
<option value="Jammu & Kashmir">Jammu & Kashmir</option>
<option value="Jharkhand">Jharkhand</option>
<option value="Karnataka">Karnataka</option>
<option value="Kerala">Kerala</option>
<option value="Madhya Pradesh">Madhya Pradesh</option>
<option value="Maharastra">Maharastra</option>
<option value="Manipur">Manipur</option>
<option value="Meghalaya">Meghalaya</option>
<option value="Mizoram">Mizoram</option>
<option value="Nagaland">Nagaland</option>
<option value="Odisha">Odisha</option>
<option value="Punjab">Punjab</option>
<option value="Rajasthan">Rajasthan</option>
<option value="Sikkim">Sikkim</option>
<option value="Tamil Nadu">Tamil Nadu</option>
<option value="Telangana">Telangana</option>
<option value="Tripura">Tripura</option>
<option value="Uttarakhand">Uttarakhand</option>
<option value="Uttar Pradesh">Uttar Pradesh</option>
<option value="West Bengal">West Bengal</option>
</select>
</td>
</tr>
<tr align="center">
<td COLSPAN="2">
<font size="3">
EMAIL:-
</FONT>
&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp <input type="text"name="email" size="50">
</td>
<td COLSPAN="2">
<font size="3">
TAX PAYER TYPE:-
</FONT>
&nbsp&nbsp&nbsp&nbspINDIVIDUAL
</td>
</tr>
<tr align="center">
<td COLSPAN="2">
<font size="3">
BANK NAME:-
</FONT>
<SELECT NAME="bank">
<option value="PUNJAB NATIONAL BANK">PUNJAB NATIONAL BANK</option>
<option value="BANK OF INDIA">BANK OF INDIA</option>
<option value="STATE BANK OF INDIA">STATE BANK OF INDIA</option>
<option value="KOTAK MAHINDRA BANK">KOTAK MAHINDRA BANK</option>
<option value="AXIS BANK">AXIS BANK</option>
<option value="BANK OF BARODA">BANK OF BARODA</option>
<option value="INDIAN BANK">INDIAN BANK</option>
<option value="ICICI BANK">ICICI BANK</option>
<option value="IDBI BANK">IDBI BANK</option>
<option value="HDFC BANK">HDFC BANK</option>
<option value="ALLAHABAD BANK">ALLAHABAD BANK</option>
<option value="UNION BANK">UNION BANK</option>
<option value="YES BANK">YES BANK</option>
<option value="SYNDICATE BANK">SYNDICATE BANK</option>
</select>
</td>
<td COLSPAN="2">
BANK ACCOUNT NO:-
</FONT>
&nbsp&nbsp&nbsp&nbsp&nbsp <input type="text"name="account" size="50" maxlength="16" onChange="ch2()">
</td>
</tr>
<TR ALIGN="CENTER">
<TD COLSPAN="4">
<input type ="submit" name="submit" value="REGISTER NOW">&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<input type="reset" VALUE="RESET">
</TD>
</TR>
</table>
</form>
<script>
function ch()
{
	var a=frm.pan.value;
	var b=a.length;
	if (b!==14)
	{
		alert('Please Check Your PAN NO.');
	}
}
function ch2()
{
	var c=frm.account.value;
	var d=c.length;
	if (d!==16)
	{
		alert('Please Check Your BANK ACCOUNT NO.');
	}
	else
	{
		alert('PLEASE CHECK YOUR ALL DATA ONCE AGAIN.......');
	}
}
</script>
</body>
</html>