<html><head>
<title>INCOME TAX</title>
</head>
<body>
<?php
$a=getdate();
$b=$a['mday'];
$c=$a['mon'];
$d=$a['year'];

echo "<table bgcolor='#557598' width='100%' border='0' align='center'>"
."<tr align='right'>"
."<td width='84%'>"
."<img src='twtr.png'>"
."</td>"
."<td align='center'>"
."<font color='sky blue'>"
."ASK   1800 180 1961/1961"
."</FONT>"
."</TD>"
."</TR>"
."</TABLE>"
."<table bgcolor='#DFEBF9' width='100%' border='0' align='center'>"
."<tr align='left'>"
."<td align='center'>"
."<font color='#056BD6'>"
."DATE:- ".$b."-".$c."-".$d
."</TD>"
."<td width='60%'>"
."<font color='SKY BLUE'>"
."INCOME TAX DEPARTMENT"
."</FONT>"
." > "
."<font color='GRAY'>"
."ABOUT US"
."</FONT>"
."</td>"
."<td ALIGN='RIGHT'>"
."FOLLOW US ON"
."<a href='http://www.facebook.com'><img src='fb.png' height='6%' width='10%'></a>"
."<a href='http://www.twitter.com'><img src='twt.png' height='6%' width='10%'></a>"
."<a href='http://www.youtube.com'><img src='U_tub.png' height='6%' width='10%'></a>"
."</TD>"
."</TR>"
."</TABLE>";
?>
<hr size="5" color="orange">
<img src="logo2.jpg" align="left" height="23%" width="13%">
<img src="logo3.jpg" align="right" height="23%" width="13%"><br>
<center><font color="crymson" face="Segoe Print" size="7"><b><u>INCOME TAX DEPARTMENT</u></b></font></center>
<hr size="2" color="navy">
<br><marquee behavior="alternate" scrollamount="7" width="100%">
<font color="blue">*Press note regarding: Filing of Revised Income Tax Returns by the Tax Payers Post De-Monetisation of Currency</font></marquee>
<br><br><br>
<font face="times new roman" color="crymson" size=+1 align="justified">
<p>
The Income Tax Department, also referred to as IT Department, is a government agency in charge of monitoring the income tax collection by the Government of India. It functions under the Department of Revenue of the Ministry of Finance.[1] It is responsible for administering following direct taxation acts passed by Parliament of India.[2]
<br><br>
The Income-tax Act, 1961<br>
Expenditure Tax Act, 1987<br>
Various Finance Acts (Passed Every Year in Budget Session)<br>
The IT Department is also responsible for enforcing the Double Taxation Avoidance Agreements and deals with various aspects of international taxation such as Transfer pricing. Finance Act, 2012 seeks to grant Income Tax Department powers to combat aggressive Tax avoidance by enforcing General Anti Avoidance Rules.[3]
<br><img src="img1.jpg" height='100' width='150' align="right">
Management<br><br>
The Central Board of Direct Taxes (CBDT) is a part of Department of Revenue in the Ministry of Finance. The CBDT provides inputs for policy and planning of direct taxes in India, and is also responsible for administration of direct tax laws through the IT Department. The CBDT is a statutory authority functioning under the Central Board of Revenue Act, 1963. The officials of the Board in their ex officio capacity also function as a division of the Ministry dealing with matters relating to levy and collection of direct taxes. The CBDT is headed by Chairman and also comprises six members, all of whom are ex officio Special Secretary to the Government of India.
<br><br>
The Chairman and members of the CBDT are selected from the Indian Revenue Service (IRS), whose members constitute the top management of the IT Department. The Chairman and every member of CBDT are responsible for exercising supervisory control over definite areas of field offices of IT Department, known as Zones.<img src="img13.jpg" height='100' width='150' align="right"> Various functions and responsibilities of the CBDT are distributed amongst Chairman and six members, with only fundamental issues reserved for collective decision by the CBDT. The areas for collective decision by the CBDT include policy regarding discharge of statutory functions of the CBDT and of the Union Government under the various direct tax laws. They also include general policy relating to:<br>
<br>
Set up and structure of Income Tax Department;<br>
Methods and procedures of work of the CBDT;<br>
Measures for disposal of assessments, collection of taxes, prevention and detection of tax evasion and tax avoidance;<br><img src="img7.jpg" height='100' width='150' align="right">
Recruitment, training and all other matters relating to service conditions and career prospects of all personnel of the Income-tax Department;<br>
Laying down of targets and fixing of priorities for disposal of assessments and collection of taxes and other related matters;<br>
Write off of tax demand exceeding Rs.25 lakhs in each case;<br>
Policy regarding grant of rewards and appreciation certificates.<br>
Any other matter, which the Chairman or any Member of the Board, with the approval of the Chairman, may refer for joint consideration of the Board.
</p><p align="right"><a href="home.php"><img src="back.jpg"height="6%"width="4%">Go Back</a>
<hr color='orange'><hr color='green'><br>

</p></font>
</body>
</HTML>