<html>
<head>
<title>TAX_CALC</title>
</head>
<body background="images_036.png">
<?php
$a=getdate();
$b=$a['mday'];
$c=$a['mon'];
$d=$a['year'];

echo "<table bgcolor='#557598' width='100%' border='0' align='center'>"
."<tr align='right'>"
."<td width='84%'>"
."<img src='twtr.png'>"
."</td>"
."<td align='center'>"
."<font color='sky blue'>"
."ASK   1800 180 1961/1961"
."</FONT>"
."</TD>"
."</TR>"
."</TABLE>"
."<hr height='2%'>"
."<table bgcolor='#DFEBF9' width='100%' border='0' align='center'>"
."<tr align='left'>"
."<td align='center'>"
."<font color='#056BD6'>"
."DATE:- ".$b."-".$c."-".$d
."</TD>"
."<td width='50%'>"
."<font color='SKY BLUE'>"
."INCOME TAX DEPARTMENT"
."</FONT>"
." > "
."<font color='GRAY'>"
."TAX CALCULATOR"
."</FONT>"
."</td>"
."<td ALIGN='RIGHT'>"
."FOLLOW US ON"
."<a href='http://www.facebook.com'><img src='fb.png' height='21' width='23'></a>"
."<a href='http://www.twitter.com'><img src='twt.png' height='21' width='23'></a>"
."<a href='http://www.youtube.com'><img src='U_tub.png' height='21' width='23'></a>"
."  "
."<a href='home.php'>"
."<img src='back.jpg' height='25' width='25'>"
."GO HOME"
."</a>"
."</TD>"
."</TR>"
."</TABLE>";
?>

<table border="0" width="100%" height="40%">
<tr align="center">
<td width="50%">
<marquee direction="left" scrollamount="13"  behavior="slide">
<div class="slideshow-container" align="right">
<div class="mySlides fade">
<img src="cal (1).jpg" style="width:650;height:220">
</div>
<div class="mySlides fade">
<img src="cal (2).jpg" style="width:650;height:220">
</div>
<div class="mySlides fade">
<img src="cal (3).jpg" style="width:650;height:220">
</div>
<div class="mySlides fade">
<img src="cal (4).jpg" style="width:650;height:220">
</div>
</div>
<br>
<div style="text-align:center">
<span class="dot"></span>
<span class="dot"></span>
<span class="dot"></span>
<span class="dot"></span>
</div>
<script>
var slideIndex=3;
showSlides();
function showSlides()
{
var i;
var slides=document.getElementsByClassName("mySlides");
var dots=document.getElementsByClassName("dot");
for (i=0; i<slides.length; i++)
{
slides[i].style.display="none";
}
slideIndex++;
if (slideIndex>slides.length)
{
slideIndex=1;
}
for (i=0; i<dots.length; i++)
{
dots[i].className=dots[i].className.replace("active","");
}
slides[slideIndex-1].style.display="block";
dots[slideIndex-1].className+="active";
setTimeout(showSlides,6740);
}
</script>
</marquee>
</td>
<td width="50%">
<marquee direction="left" scrollamount="13"  behavior="slide">
<div class="slideshow-container" align="right">
<div class="mySlide fade">
<img src="cal (5).jpg" style="width:650;height:220">
</div>
<div class="mySlide fade">
<img src="cal (6).jpg" style="width:650;height:220">
</div>
<div class="mySlide fade">
<img src="cal (7).jpg" style="width:650;height:220">
</div>
<div class="mySlide fade">
<img src="cal (8).jpg" style="width:650;height:220">
</div>
</div>
<br>
<div style="text-align:center">
<span class="do"></span>
<span class="do"></span>
<span class="do"></span>
<span class="do"></span>
</div>
<script>
var slideInde=3;
showSlide();
function showSlide()
{
var i;
var slide=document.getElementsByClassName("mySlide");
var dot=document.getElementsByClassName("do");
for (i=0; i<slide.length; i++)
{
slide[i].style.display="none";
}
slideInde++;
if (slideInde>slide.length)
{
slideInde=1;
}
for (i=0; i<dot.length; i++)
{
dot[i].className=dot[i].className.replace("active","");
}
slide[slideInde-1].style.display="block";
dot[slideInde-1].className+="active";
setTimeout(showSlide,6000);
}
</script>
</marquee>
</td>
</tr>
</table>
<form  name="frm" method="post" action="http://localhost/inc_file/calc.php">
<table width="60%" border="0" bgcolor="#FA7277" HEIGHT="10%" align="center">
<tr>
<td bgcolor="#FA7277" align="center"><font color="#007168" size="6" face="chiller"><b><u>INCOME TAX CALCULATOR</U></b></font></td>
</tr>
</table>
<table bgcolor="#E7A7B6" width="60%" border="0" HEIGHT="70%" align="center">
<tr ALIGN="center" >
<td>
ASSESSMENT YEAR:- 
</TD>
<TD>
2017-18
</td>
</tr>

<tr ALIGN="center">
<td>
TAX PAYER:- 
</TD>
<TD>
<select size="0">
<option>INDIVIDUAL</option>
</select>
</td>
</tr>
<tr ALIGN="center">
<td>
ENTER YOUR INCOME:- 
</TD>
<TD>
<input type="text" name="t1" size="30">
</td>
</tr>
<tr ALIGN="center">
<td>
DEDUCTION:- 
</TD>
<TD>
<input type="text" name="t2" size="30" readonly>
</td>
</tr>
<tr ALIGN="center">
<td>
NET LEFT AMOUNT:- 
</TD>
<TD>
<input type="text" name="t3" size="30" readonly>
</td>
</tr>
<tr>
<Td colspan="2" align="center">
<input type="button" name="submit" value="Calculate" onClick="calc()">
<input type="reset" value="Reset">
</td>
</tr>
<script type="text/javascript">
function calc()
{
var income=frm.t1.value;
var ded;
var left;
if(income<=250000)
{
		left=income;
		ded=0;
}	
else if((income>250000)&&(income<=500000))
{
		
		var a=income-250000;
		ded=((a*10)/100)+5000;
		left=income-ded;
}	
else if((income>500000)&&(income<=1000000))
{
		
		var a=income-500000;
		ded=((a*20)/100)+25000;
		left=income-ded;
}	
else
{
		
		var a=income-1000000;
		ded=((a*30)/100)+120000;
		left=income-ded;
}	
frm.t2.value=ded;
frm.t3.value=left;
}
</script>
</TABLE>
</FORM>
</BODY>
</HTML>