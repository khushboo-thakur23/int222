<html>
<head>
<TITLE>
USER LOGIN
</TITLE>
</HEAD>
<BODY background="logbg.jpg">
<FORM action="http://localhost:/inc_file/login.php" method="post">
<?php
$a=getdate();
$b=$a['mday'];
$c=$a['mon'];
$d=$a['year'];

echo "<table bgcolor='#557598' width='100%' border='0' align='center'>"
."<tr align='right'>"
."<td width='84%'>"
."<img src='twtr.png'>"
."</td>"
."<td align='center'>"
."<font color='sky blue'>"
."ASK   1800 180 1961/1961"
."</FONT>"
."</TD>"
."</TR>"
."</TABLE>"
."<table bgcolor='#DFEBF9' width='100%' border='0' align='center'>"
."<tr align='left'>"
."<td align='center'>"
."<font color='#056BD6'>"
."DATE:- ".$b."-".$c."-".$d
."</TD>"
."<td width='60%'>"
."<font color='SKY BLUE'>"
."INCOME TAX DEPARTMENT"
."</FONT>"
." > "
."<font color='GRAY'>"
."USER LOGIN"
."</FONT>"
."</td>"
."<td ALIGN='RIGHT'>"
."FOLLOW US ON"
."<a href='http://www.facebook.com'><img src='fb.png' height='21' width='23'></a>"
."<a href='http://www.twitter.com'><img src='twt.png' height='21' width='23'></a>"
."<a href='http://www.youtube.com'><img src='U_tub.png' height='21' width='23'></a>"
."  "
."<a href='home.php'>"
."<img src='back.jpg' height='25' width='25'>"
."GO HOME"
."</a>"
."</TD>"
."</TR>"
."</TABLE>";
$srvname="localhost";
$usrname="root";
$pass="";
$db="income_tax";
//create connection
if (isset($_POST['b1']))
{
	$f=0;
$con=new mysqli($srvname,$usrname,$pass,$db);
if($con->connect_error)
{
	echo "PLEASE ENTER CORRECTDATA";
}
else
{
$readdata="select USER_NAME,PASSWORD from registration";
$result=$con->query($readdata);
while($row=$result->fetch_assoc())
{
$usr=$row["USER_NAME"];
$pas=$row["PASSWORD"];
$user=$_POST['t1'];
$pass=$_POST['t2'];
if (($user==$usr) && ($pass==$pas))
{
	$f=1;
	break;
}
}
if ($f==1)
{
	header('location: payuser.php');
}
else
{
	echo "<FONT COLOR='RED' SIZE='3'>"."<B>"."ACCESS DENIED... KINDLY ENTER VADIL USER NAME AND PASSWORD "."</B>"."</FONT>";
}
}
}
?>

<marquee behavior="alternate" scrollamount="7" width="100%">
<font color="orange"> *​ Press note regarding : Payments towards Tax, Penalty, Surcharge and Deposit under PMGKY 2016 in Old Demonetised Currency​</font></marquee>
<table border="0"  width="100%" height="60%" margin="top">
<tr>
<td rowspan="5" width="27%">
<div class="slideshow-container" align="left" >
<div class="mySlides fade">
<img src="usr (1).jpg" width="370" height="360">
</div>
<div class="mySlides fade">
<img src="usr (2).jpg" style="width:370;height:360">
</div>
<div class="mySlides fade">
<img src="usr (3).jpg" style="width:370;height:360">
</div>
<div class="mySlides fade">
<img src="usr (4).jpg" style="width:370;height:360">
</div>
</div>
<div style="text-align:center">
<span class="dot"></span>
<span class="dot"></span>
<span class="dot"></span>
<span class="dot"></span>
</div>
<script>
var slideIndex=3;
showSlides();
function showSlides()
{
var i;
var slides=document.getElementsByClassName("mySlides");
var dots=document.getElementsByClassName("dot");
for (i=0; i<slides.length; i++)
{
slides[i].style.display="none";
}
slideIndex++;
if (slideIndex>slides.length)
{
slideIndex=1;
}
for (i=0; i<dots.length; i++)
{
dots[i].className=dots[i].className.replace("active","");
}
slides[slideIndex-1].style.display="block";
dots[slideIndex-1].className+="active";
setTimeout(showSlides,4700);
}
</script>
</td>
<td colspan="2" align="center" bgcolor="#00AF8A" height="20%">
<font size="6"color="" FACE="Harrington">
<b><u>EMPLOYEE LOGIN</u></b>
</FONT><BR>
<font size="3"color="red" FACE="ARIAL">
(Only For Officers Of The Income Tax Department)
</font>
</TD>
<td rowspan="5" width="27%">
<div class="slideshow-container" align="right" >
<div class="mySlide fade">
<img src="usr (1).png" width="370" height="360">
</div>
<div class="mySlide fade">
<img src="usr (5).jpg" style="width:370;height:360">
</div>
<div class="mySlide fade">
<img src="usr (6).jpg" style="width:370;height:360">
</div>
<div class="mySlide fade">
<img src="usr (7).jpg" style="width:370;height:360">
</div>
</div>
<div style="text-align:center">
<span class="do"></span>
<span class="do"></span>
<span class="do"></span>
<span class="do"></span>
</div>
<script>
var slideInde=3;
showSlide();
function showSlide()
{
var i;
var slide=document.getElementsByClassName("mySlide");
var dot=document.getElementsByClassName("do");
for (i=0; i<slide.length; i++)
{
slide[i].style.display="none";
}
slideInde++;
if (slideInde>slide.length)
{
slideInde=1;
}
for (i=0; i<dot.length; i++)
{
dot[i].className=dot[i].className.replace("active","");
}
slide[slideInde-1].style.display="block";
dot[slideInde-1].className+="active";
setTimeout(showSlide,4000);
}
</script>
</td>
</tr>
<tr  bgcolor="#FA7277">
<td ALIGN="CENTER">
<font size="4"color="yellow" FACE="Harrington">
ENTER USER NAME:-
</FONT>
</TD>
<TD align="center">
<input type="text" name="t1" size="30">
</td>
</tr>
<tr  bgcolor="#FA7277">
<td ALIGN="CENTER">
<font size="4"color="yellow" FACE="Harrington">
ENTER YOUR PASSWORD:-
</FONT>
</TD>
<td ALIGN="CENTER">
<input type="password" name="t2" size="30">
</td>
</tr>
<TR bgcolor="#FA7277" height="20%">
<TD COLSPAN="2" align="center">
<input type="submit" value="LOGIN" name="b1">
<br>
<font size="1.5" FACE="Times New Roman">
<A HREF="forget.php" alink="red">FORGET PASSWORD?</a>
</font>
<br>
<font size="1.5" FACE="Times New Roman">
NEW USER?
</font>
<font size="1.5" FACE="Times New Roman">
<A HREF="regis.php" alink="red">REGISTER NOW</A>
<p align="right"><a href='home.php'>
<img src='back.jpg' height='15' width='16'>
GO HOME</p>
</font>
</td>
</tr>
</table>
</FORM>
<hr size="5" color="yellow">
<hr size="5" color="lime">
<marquee scrollamount="5"><script>
for (a=1 ;a<=18 ;a++)
{
	document.write("<img src='clipart/clip ("+a+").jpg' height='150' width='150' border='3'>");
}
</script>
</marquee>
<hr size="5" color="#4D04A3">
<hr size="5" color="red">
</body>
</html>